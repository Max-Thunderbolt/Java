public interface iEstateAgent {
    String getAgentName();
    double getPropertyPrice();
    double getAgentCommission();
}
