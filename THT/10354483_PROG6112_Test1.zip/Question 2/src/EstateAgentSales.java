public class EstateAgentSales extends EstateAgent{

    EstateAgentSales(){}

    EstateAgentSales(String name, double price){
        super(name, price);
    }

    public String printPropertyReport(){
        return "ESTATE AGENT NAME: " + getAgentName() + "\nPROPERTY PRICE: " + getPropertyPrice() + "\nAGENT COMMISSION: " + getAgentCommission();
    }
}
