import java.util.InputMismatchException;
import java.util.Scanner;

public class RunApplication extends EstateAgentSales {

    static void runApplication() {
        Scanner sc = new Scanner(System.in);
        String name = "";
        double price = 0;

        try {
            System.out.print("Enter the current estate agent name: ");
            name = sc.nextLine();
            System.out.print("Enter the property price: ");
            price = sc.nextDouble();
        } catch (InputMismatchException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("\nESTATE AGENT REPORT \n*******************");
        EstateAgentSales agent1 = new EstateAgentSales(name, price);
        System.out.println(agent1.printPropertyReport());
    }

    public static void main(String[] args) {
        runApplication();
    }
}
