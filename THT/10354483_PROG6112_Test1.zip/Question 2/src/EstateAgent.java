abstract class EstateAgent implements  iEstateAgent {
    private String agentName;
    private double propertyPrice;

    private final double agentCommission = 0.2;

    EstateAgent(){}

    EstateAgent(String name, double price){
        this.agentName = name;
        this.propertyPrice = price;
    }

    @Override
    public String getAgentName(){
        return this.agentName;
    }

    @Override
    public double getPropertyPrice(){
        return this.propertyPrice;
    }

    @Override
    public double getAgentCommission(){
        return this.agentCommission * this.propertyPrice;
    }

}
